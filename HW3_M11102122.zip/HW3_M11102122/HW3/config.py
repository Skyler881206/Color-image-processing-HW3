IMAGE_PATH = r"C:\Users\usaco\Desktop\Course\Color Image Processing\HW3\train1000"
SAVE_PATH = r"C:\Users\usaco\Desktop\Course\Color Image Processing\HW3\save_figure"
BATCH = 200
